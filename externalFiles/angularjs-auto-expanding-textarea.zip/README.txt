A Pen created at CodePen.io. You can find this one at https://codepen.io/kpourdeilami/pen/KDepk.

 This is an easy to use auto-expanding textarea with angularjs. No other library required!